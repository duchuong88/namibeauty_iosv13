# cser21_ios
for ios

- Clone source code
- Chọn team, Bundle Identifier
- Tạo AppIcon
- Tạo Google Firebase => GoogleService-Info.plist
- Đổi đường link "https://cser.vn/app/index21.aspx" thành link mới trong embed21.html 
- Chạy test
